
public class Main {
    public static void main(String[] args) throws InterruptedException {
        Robot robot = new Robot();

        robot.chooseRoom();





    }
}